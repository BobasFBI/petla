using System;

class MainClass {
  public static void Main (string[] args) {
    string[] tydzien = {"Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota", "Niedziela",};
    Console.WriteLine("Poniżej dni tygodnia:");
    for (int i=0; i<tydzien.Length; i++)
    Console.WriteLine(tydzien[i]);
    Console.WriteLine("Pozdrawiam i życzę smacznej kawusi");

  }
}